package com.sara.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings

/**
 * CommandProcessor takes recognized speech text and decides what SARA should do.
 * Supports simple English + Hinglish keywords. Extend the `when` blocks below
 * to add more commands.
 *
 * Returns a String -> what SARA should speak back to the user (via TextToSpeech).
 */
class CommandProcessor(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var torchOn = false

    fun process(rawText: String): String {
        val text = rawText.lowercase().trim()

        return when {
            // ---------- Calling ----------
            text.startsWith("call ") -> {
                val number = text.removePrefix("call ").trim()
                makeCall(number)
            }

            // ---------- SMS ----------
            text.startsWith("message ") || text.startsWith("sms ") -> {
                // format: "message 9876543210 hello there"
                val parts = text.substringAfter(" ").trim().split(" ", limit = 2)
                if (parts.size == 2) sendSms(parts[0], parts[1])
                else "Please say: message [number] [your text]"
            }

            // ---------- Open an app ----------
            text.startsWith("open ") -> {
                val appName = text.removePrefix("open ").trim()
                openApp(appName)
            }

            // ---------- Web search ----------
            text.startsWith("search ") -> {
                val query = text.removePrefix("search ").trim()
                webSearch(query)
            }

            // ---------- Navigation via Accessibility Service ----------
            text.contains("go back") -> {
                SaraAccessibilityService.instance?.goBack()
                "Going back"
            }
            text.contains("go home") || text == "home" -> {
                SaraAccessibilityService.instance?.goHome()
                "Going home"
            }
            text.contains("recent apps") || text.contains("open recents") -> {
                SaraAccessibilityService.instance?.openRecents()
                "Opening recent apps"
            }
            text.contains("notifications") -> {
                SaraAccessibilityService.instance?.openNotifications()
                "Opening notifications"
            }
            text.contains("screenshot") -> {
                SaraAccessibilityService.instance?.takeScreenshot()
                "Taking a screenshot"
            }
            text.startsWith("click on ") || text.startsWith("tap on ") -> {
                val target = text.substringAfter("on ").trim()
                val success = SaraAccessibilityService.instance?.clickOnText(target) ?: false
                if (success) "Tapped on $target" else "Could not find $target on screen"
            }

            // ---------- Settings toggles ----------
            text.contains("wifi") -> {
                context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlag())
                "Opening WiFi settings"
            }
            text.contains("bluetooth") -> {
                context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlag())
                "Opening Bluetooth settings"
            }
            text.contains("flashlight") || text.contains("torch") -> {
                toggleFlashlight(text.contains("on") || !text.contains("off"))
            }
            text.contains("volume up") -> {
                audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                "Volume increased"
            }
            text.contains("volume down") -> {
                audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                "Volume decreased"
            }

            // ---------- Alarm ----------
            text.startsWith("set alarm for ") -> {
                setAlarm(text.removePrefix("set alarm for ").trim())
            }

            // ---------- Battery ----------
            text.contains("battery") -> {
                val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                "Battery is at $level percent"
            }

            else -> "Sorry, I did not understand that command yet."
        }
    }

    private fun Intent.addFlag(): Intent = this.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }

    private fun makeCall(number: String): String {
        return try {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).addFlag()
            context.startActivity(intent)
            "Calling $number"
        } catch (e: SecurityException) {
            "Call permission not granted"
        }
    }

    private fun sendSms(number: String, message: String): String {
        return try {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).addFlag()
            intent.putExtra("sms_body", message)
            context.startActivity(intent)
            "Message ready to send to $number"
        } catch (e: Exception) {
            "Could not send message"
        }
    }

    private fun openApp(appName: String): String {
        val pm = context.packageManager
        val match = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().contains(appName, ignoreCase = true)
        }
        return if (match != null) {
            val launchIntent = pm.getLaunchIntentForPackage(match.packageName)
            if (launchIntent != null) {
                context.startActivity(launchIntent.addFlag())
                "Opening ${pm.getApplicationLabel(match)}"
            } else "Found $appName but could not launch it"
        } else {
            "Could not find an app called $appName"
        }
    }

    private fun webSearch(query: String): String {
        val intent = Intent(Intent.ACTION_WEB_SEARCH)
        intent.putExtra(android.app.SearchManager.QUERY, query)
        intent.addFlag()
        context.startActivity(intent)
        return "Searching for $query"
    }

    private fun toggleFlashlight(turnOn: Boolean): String {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull() ?: return "No camera found"
            cameraManager.setTorchMode(cameraId, turnOn)
            torchOn = turnOn
            if (turnOn) "Flashlight turned on" else "Flashlight turned off"
        } catch (e: Exception) {
            "Could not control flashlight"
        }
    }

    private fun setAlarm(timeText: String): String {
        // very simple parser expecting "7 30" or "7:30" style speech-to-text output
        val cleaned = timeText.replace(":", " ").trim()
        val parts = cleaned.split(" ").filter { it.isNotBlank() }
        val hour = parts.getOrNull(0)?.toIntOrNull()
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
        return if (hour != null) {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "Alarm set for $hour $minute"
        } else {
            "Sorry, I could not understand the time"
        }
    }
}
