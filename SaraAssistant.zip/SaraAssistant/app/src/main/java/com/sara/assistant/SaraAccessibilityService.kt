package com.sara.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * SaraAccessibilityService gives SARA "deep control" over the phone:
 *  - Global navigation: back, home, recents, screenshot, notifications
 *  - Finding and tapping on-screen elements by their visible text
 *    (e.g. "SARA, click on Send" while WhatsApp is open)
 *
 * IMPORTANT: The user must manually enable this in
 * Settings > Accessibility > Installed Services > SARA
 * (Android does not allow apps to turn this on programmatically, for security reasons).
 */
class SaraAccessibilityService : AccessibilityService() {

    companion object {
        // Static reference so CommandProcessor can call into this running service
        var instance: SaraAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 100
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // We don't need to react to every event right now, but this callback
        // is where you'd add logic like "read notifications aloud" in the future.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    // ---------- Global navigation actions ----------

    fun goBack() = performGlobalAction(GLOBAL_ACTION_BACK)

    fun goHome() = performGlobalAction(GLOBAL_ACTION_HOME)

    fun openRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun openNotifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun takeScreenshot() = performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)

    // ---------- Tap-by-text: find a visible node containing given text and click it ----------

    fun clickOnText(targetText: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodeByText(root, targetText.trim())
        if (node != null) {
            // Prefer clicking the node itself; if it's not clickable, try its parent
            var clickable: AccessibilityNodeInfo? = node
            while (clickable != null && !clickable.isClickable) {
                clickable = clickable.parent
            }
            return clickable?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
        }
        return false
    }

    private fun findNodeByText(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        if (node.text?.toString()?.contains(text, ignoreCase = true) == true ||
            node.contentDescription?.toString()?.contains(text, ignoreCase = true) == true
        ) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findNodeByText(child, text)
            if (result != null) return result
        }
        return null
    }
}
